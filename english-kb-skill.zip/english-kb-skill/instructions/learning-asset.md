# Learning Asset Task

## Goal

Create learning material that helps a learner understand, distinguish, remember,
or apply an existing Knowledge Point.

Learning Assets are pedagogical representations of the Knowledge Point. They are
not replacements for the canonical Knowledge Point.

## Required Inputs

Use:

- `schemas/schema-learning-asset.json`
- the target Knowledge Point
- existing Learning Assets if the repository contains them

Typical parameters:

```text
Target Type
Difficulty
Audience
Language
Compare With
```

## Target Types

Supported target types are those defined by `schema-learning-asset.json`.

Common examples include:

- `KNOWLEDGE_POINT`
- `DEFINITION`
- `EXAMPLE`
- `EXPRESSION`
- `CLASSIFICATION`
- `COMPARISON`
- `ASSOCIATION`
- `SCENARIO`
- `COUNTER_EXAMPLE`
- `CONFUSION`
- `MNEMONIC`
- `EXTENSION`

Do not invent target types.

## Generation Rules

1. Read the target Knowledge Point completely.
2. Read existing Learning Assets for that Knowledge Point.
3. Generate only the requested Target Type.
4. If `COMPARISON` is requested and `Compare With` is supplied, compare exactly
   those concepts.
5. Do not simply copy the base definition.
6. Prefer learner-useful explanations, examples, contrasts, and application.
7. Keep examples appropriate to the requested difficulty.
8. Avoid semantically duplicate assets.
9. If an existing asset can be updated instead of creating another duplicate,
   update it only when the user permits updates.

## Multiple Samples

If the schema's `content` field is an array, put multiple related samples in the
same Personal/Learning Asset object when they belong to the same logical asset.

Do not create one file per sample unless the repository schema or user explicitly
requires that structure.

For example:

```json
{
  "targetType": "EXAMPLE",
  "content": [
    { "...": "example 1" },
    { "...": "example 2" },
    { "...": "example 3" }
  ]
}
```

## Output

Write the generated asset to the repository's established Learning Asset
directory.

Validate against `schema-learning-asset.json`.

Report only a concise summary after writing.
